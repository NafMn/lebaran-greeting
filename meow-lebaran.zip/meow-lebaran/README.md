# 🐱 Meow Lebaran 1446 H

App ucapan Idul Fitri bertema kucing — AI Generator (GLM-4-Flash/Z.ai) + komentar publik + Dana Kaget.

## Stack
- **Runtime**: Node.js (Express)
- **Database**: PostgreSQL (via `pg`)
- **AI**: GLM-4-Flash via Z.ai (`open.bigmodel.cn`)
- **Frontend**: Vanilla HTML/CSS/JS (no build step)

---

## 🚀 Cara Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Setup environment
```bash
cp .env.example .env
# Edit .env, isi semua variabel
```

### 3. Isi .env
```env
PORT=3000
DATABASE_URL=postgres://user:password@localhost:5432/meow_lebaran
GLM_API_KEY=your_key_dari_bigmodel.cn
SITE_OWNER=Nama Kamu
```

### 4. Buat database PostgreSQL
```bash
# Dengan psql
psql -U postgres -c "CREATE DATABASE meow_lebaran;"

# Lalu jalankan migration
node src/db-init.js
```

### 5. Jalankan server
```bash
# Production
npm start

# Development (auto-reload)
npm run dev
```

Buka: http://localhost:3000

---

## 📁 Struktur

```
meow-lebaran/
├── public/
│   └── index.html        # Frontend lengkap (HTML + CSS + JS)
├── src/
│   ├── server.js         # Express server + semua route API
│   ├── db.js             # PostgreSQL pool
│   ├── ai.js             # GLM-4-Flash wrapper + fallback
│   └── db-init.js        # Migration/schema creator
├── .env.example
└── package.json
```

---

## 🔌 API Endpoints

| Method | URL | Deskripsi |
|--------|-----|-----------|
| `GET`  | `/api/ucapan?nama=X&gaya=lucu` | Generate ucapan AI |
| `GET`  | `/api/komentar` | Ambil semua komentar |
| `POST` | `/api/komentar` | Kirim komentar baru |

**gaya**: `lucu` \| `formal` \| `puisi`

**POST body**:
```json
{ "nama": "Budi", "pesan": "Selamat Lebaran!", "whatsapp": "081234567890" }
```

---

## 🔑 Dapat GLM API Key

1. Daftar di https://bigmodel.cn
2. Masuk ke User Center → API Keys
3. Buat key baru
4. Isi ke `GLM_API_KEY` di `.env`

Model yang digunakan: `glm-4-flash` (gratis / sangat murah)

---

## 🎁 Cara Kirim Dana Kaget

Nomor WA tersimpan private di PostgreSQL. Untuk memilih pemenang:

```sql
-- Lihat komentar yang belum dapat reward
SELECT id, nama, pesan, whatsapp, created_at
FROM komentar
WHERE rewarded = FALSE
ORDER BY RANDOM()
LIMIT 5;

-- Tandai sudah rewarded
UPDATE komentar SET rewarded = TRUE WHERE id = <ID>;
```

---

## ☁️ Deploy

### Railway / Render / Heroku
1. Push ke GitHub
2. Connect repo ke platform
3. Set environment variables (PORT, DATABASE_URL, GLM_API_KEY)
4. Jalankan `node src/db-init.js` sekali via console

### VPS / Coolify
```bash
npm install
node src/db-init.js
npm start
# Tambahkan Nginx reverse proxy ke port 3000
```
