// src/ai.js
// GLM-4-Flash via Z.ai (open.bigmodel.cn) dengan fallback jika API gagal

const FALLBACK = [
  'Meong~! Minal Aidin Wal Faizin 🐱 Semoga Lebaran ini membawa kebahagiaan sebesar perut kucing kenyang. Mohon maaf lahir dan batin ya! 🙏',
  'Purrrr... Selamat Idul Fitri 1446 H! Seperti kucing yang selalu pulang ke rumah, semoga kita kembali ke fitrah yang suci. Maafkan segala khilaf! 😺',
  'Nyaow~! Taqabbalallahu minna wa minkum! Semoga amal ibadah kita diterima, sehappy kucing dapat ikan segar. Mohon maaf lahir batin! 🐾',
  'Mrrrow! Selamat Hari Raya! Semoga hidupmu se-cozy kucing tidur di sofa hangat seharian. Mohon maaf atas segala kesalahan! 😸',
  'Meow Meow~! Happy Eid Mubarak! Semoga rezekimu semelimpah mangkuk makan kucing yang selalu terisi penuh. Maaf lahir dan batin! 🐈',
];

function getFallback(nama) {
  const msg = FALLBACK[Math.floor(Math.random() * FALLBACK.length)];
  return nama ? `Untuk ${nama}, ` + msg : msg;
}

/**
 * Generate ucapan Lebaran via GLM-4-Flash
 * @param {string} nama - nama penerima (opsional)
 * @param {string} gaya - 'lucu' | 'formal' | 'puisi'
 * @returns {{ ucapan: string, source: 'ai'|'fallback' }}
 */
async function generateUcapan(nama = '', gaya = 'lucu') {
  const apiKey = process.env.GLM_API_KEY;
  if (!apiKey) {
    return { ucapan: getFallback(nama), source: 'fallback' };
  }

  const gayaMap = {
    lucu:   'gaya lucu menggemaskan, banyak analogi kucing, pakai 1-2 emoji kucing',
    formal: 'gaya formal dan sopan, sisipkan 1 analogi kucing secara elegan, tanpa emoji',
    puisi:  'bentuk puisi 4 baris berirama, bertema kucing dan Lebaran, bahasa puitis',
  };

  const systemPrompt = 'Kamu asisten ucapan Lebaran bertema kucing. Selalu sisipkan unsur kucing. Jawaban singkat, max 3 kalimat (kecuali puisi). Jangan pakai tanda petik di awal/akhir.';
  const userPrompt = nama
    ? `Buat ucapan Idul Fitri 1446 H personal untuk "${nama}" dengan ${gayaMap[gaya] || gayaMap.lucu}.`
    : `Buat ucapan Idul Fitri 1446 H dengan ${gayaMap[gaya] || gayaMap.lucu}.`;

  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 9000);

    const res = await fetch('https://open.bigmodel.cn/api/paas/v4/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'glm-4-flash',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user',   content: userPrompt },
        ],
        max_tokens: 220,
        temperature: 0.9,
      }),
      signal: controller.signal,
    });

    clearTimeout(timer);

    if (!res.ok) throw new Error(`GLM HTTP ${res.status}`);

    const data = await res.json();
    const ucapan = data?.choices?.[0]?.message?.content?.trim();
    if (!ucapan) throw new Error('Empty response');

    return { ucapan, source: 'ai' };
  } catch (err) {
    console.error('[AI] Fallback karena:', err.message);
    return { ucapan: getFallback(nama), source: 'fallback' };
  }
}

module.exports = { generateUcapan };
